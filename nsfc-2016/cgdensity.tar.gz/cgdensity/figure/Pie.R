dt.overlap.icmpmaker.new
   summaker  sum  Type Percentage
1:        0 3924     0      40.1%
2:        1 3546   1-4      36.2%
3:        2 1427   5-8      14.6%
4:        3  804  9-12       8.2%
5:        4   96 13-14         1%
gap
   summaker  sum  Type Percentage
1:        0 5894     0      41.7%
2:        1 3318   1-4      23.5%
3:        2 2102   5-8      14.9%
4:        3 2022  9-12      14.3%
5:        4  783 13-15       5.5%

